import { CiLocationOn } from "react-icons/ci";
import { MdEditLocationAlt } from "react-icons/md";
import { AiFillDelete } from "react-icons/ai";

const icons = {
    CiLocationOn,
    MdEditLocationAlt,
    AiFillDelete
}
export default icons;