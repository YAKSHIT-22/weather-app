export const selectOptions = {
    standard: "standard",
    metric: "metric",
    imperial: "imperial",
    
}


export const baseUrl = `https://api.openweathermap.org/data/2.5/weather`